import requests
from bs4 import BeautifulSoup
import pandas as pd
import xmltodict
import json

#공공데이터포털에서 제공받은 key값
key = "IZWMa17q6c%2F7c9GxuIsta09lbD%2B2zj7e0Eblc%2BUKMeBoWo8qaHiPAFVrdohhKIOn9Q2d7f7hCbyUU%2FNdjn4r0w%3D%3D"
#링크뒤에 format(key) 붙여주기
url = "http://openapi.nature.go.kr/openapi/service/rest/PlantService/plntIlstrSearch?serviceKey=IZWMa17q6c%2F7c9GxuIsta09lbD%2B2zj7e0Eblc%2BUKMeBoWo8qaHiPAFVrdohhKIOn9Q2d7f7hCbyUU%2FNdjn4r0w%3D%3D&st=&sw=&dateGbn=&dateFrom=&dateTo=&numOfRows=5000000&pageNo=&".format(key)

#제대로 인식하고 불러와지는지 확인
# content = requests.get(url).content
# print(content)

content = requests.get(url).content
dict = xmltodict.parse(content)
jsonString = json.dumps(dict['response']['body'], ensure_ascii=False)
jsonObj = json.loads(jsonString)
# print(jsonObj)


# df = pd.DataFrame(jsonObj)
# print(df.count)
for item in jsonObj['items']['item']:
    print(item)

file = open("./nonPayment.json", "w+")
file.write(json.dumps(jsonObj['items']['item']))